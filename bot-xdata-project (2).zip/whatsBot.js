const { Client, LocalAuth } = require('whatsapp-web.js');

let client;

function initializeClient() {
  client = new Client({
    authStrategy: new LocalAuth({
      dataPath: '/tmp/session'
    }),
    puppeteer: {
      headless: true,
      args: ['--no-sandbox', '--disable-setuid-sandbox']
    }
  });

  client.on('qr', (qr) => {
    console.log('🔵 Escanea este código QR con tu WhatsApp:
', qr);
  });

  client.on('ready', () => {
    console.log('✅ Cliente conectado a WhatsApp');
  });

  client.initialize();
  return client;
}

module.exports = { client, initializeClient };
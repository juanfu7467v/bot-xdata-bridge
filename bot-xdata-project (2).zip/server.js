const express = require('express');
const { client, initializeClient } = require('./whatsBot');
const cors = require('cors');

initializeClient();

const app = express();
app.use(cors());
app.use(express.json());

app.post('/api/xdata', async (req, res) => {
  const { comando } = req.body;
  if (!comando) return res.status(400).json({ error: 'Falta el comando.' });

  const chatId = process.env.CHAT_ID;
  if (!chatId) return res.status(400).json({ error: 'CHAT_ID no está definido en las variables de entorno.' });

  try {
    const msg = await client.sendMessage(chatId, comando);
    res.json({ ok: true, id: msg.id._serialized });
  } catch (err) {
    console.error('Error al enviar mensaje:', err);
    res.status(500).json({ ok: false, error: err.toString() });
  }
});

app.get('/api/status', (req, res) => {
  res.send('✅ Bot XDATA bridge funcionando.');
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log('🚀 Servidor iniciado en el puerto', PORT));